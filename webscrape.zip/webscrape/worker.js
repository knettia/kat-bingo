setInterval(() => {
    chrome.runtime.sendMessage({ action: "next-page"});
    return;
}, 1.5 * 60 * 1000);