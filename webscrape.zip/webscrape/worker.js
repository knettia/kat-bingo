setInterval(() => {
    chrome.runtime.sendMessage({ action: "next-page"});
    return;
}, 3 * 60 * 1000);