function extractLinks() {
    
    const links = [];
    const topicListItems = document.querySelectorAll('.topic-list-body .topic-list-item');

    for (let i = 0; i < Math.min(topicListItems.length, 100); i++) {
        const mainLink = topicListItems[i].querySelector('.main-link');
        if (mainLink) {
            const linkTopLine = mainLink.querySelector('.link-top-line');
            
            if (linkTopLine) {
                const topLineTitle = linkTopLine.querySelector('.title');
                links.push(topLineTitle.getAttribute("href"));
            }
        }
    }

    return links;
}

const extractedLinks = extractLinks();
chrome.runtime.sendMessage({ action: "start-loading", links: extractedLinks });