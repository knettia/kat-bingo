let links = {};
let active = false;

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === "start-loading" && message.links && message.links.length > 0) {
    links = message.links;
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs.length > 0) {
          const currentTab = tabs[0];
          chrome.tabs.update(currentTab.id, { url: "https://devforum.roblox.com/" + links[0] });
          links.shift();
        }
      });
  } 
  
  if (message.action == "next-page" ) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs.length > 0) {
            const currentTab = tabs[0];
            if (links.length > 0) {
                chrome.tabs.update(currentTab.id, { url: "https://devforum.roblox.com/" + links[0] });
                console.log("Next page: " + links[0])
                links.shift();
            } else {
                chrome.tabs.update(currentTab.id, { url: "https://devforum.roblox.com/tag/scripting"});
                console.log("Reset!")
            }
        }
    });
  }
});

chrome.commands.onCommand.addListener(function (command) {
    if (command === "stop-loading") {
    }
});