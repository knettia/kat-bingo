let links = {};
let active = false;

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === "start-loading" && message.links && message.links.length > 0 && active === false) {
    links = message.links;
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs.length > 0) {
          const currentTab = tabs[0];
          chrome.tabs.update(currentTab.id, { url: "https://devforum.roblox.com/" + links[0] });
          links.shift();
          active = true;
        }
      });
  } 
  
  if (message.action == "next-page" && active) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs.length > 0) {
            const currentTab = tabs[0];
            if (links.length > 0) {
                chrome.tabs.update(currentTab.id, { url: "https://devforum.roblox.com/" + links[0] });
                links.shift();
            } else {
                chrome.tabs.update(currentTab.id, { url: "https://devforum.roblox.com/tag/scripting"});
            }
        }
    });
  }
});

chrome.commands.onCommand.addListener(function (command) {
    if (command === "stop-loading") {
        active = false;
    }
});